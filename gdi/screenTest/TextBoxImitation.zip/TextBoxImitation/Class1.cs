﻿/// ***********************************************************************
///
/// =================================
/// CLR版本    ：4.0.30319.42000
/// 命名空间    ：TextBoxImitation
/// 文件名称    ：Class1.cs
/// =================================
/// 创 建 者    ：lican
/// 创建日期    ：2018/11/12 15:55:06 
/// 邮箱        ：nihaolican@qq.com
/// 功能描述    ：
/// 使用说明    ：
/// =================================
/// 修改者    ：
/// 修改日期    ：
/// 修改内容    ：
/// =================================
///
/// ***********************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextBoxImitation
{
    class Class1
    {

        #region Private Fields
        #endregion

        #region Properties


        #endregion

        #region Events

        #endregion

        #region Constructors




        #endregion

        #region Control Events

        #endregion

        #region Methods



        #endregion
    }
}
